Vela brand kit

Recommended logo: assets/svg/vela-logo-horizontal-color.svg
Use the color version on light backgrounds, reverse or white on dark backgrounds, black for single color print.
Use the symbol alone only where space is tight (app icon, favicon, avatar). Keep clear space around the logo of at
least half the symbol height. Do not stretch, rotate, recolor, outline or add effects.

Colors: primary #FF4F1A, accent #FFB300, ink #0E0E10, paper #FFFFFF
Type: Archivo 800 (SIL Open Font License). All logo files have the type converted to outlines.
SVG files are vector and scale to any size. PNG files have transparent backgrounds except the app icons.
